
#include "picmodes.h"

int get_mode() {
	return mode;
}

void set_mode(int newmode) {
	mode = newmode;
}
