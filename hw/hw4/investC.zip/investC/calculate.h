#ifndef CALCULATE__H__
#define CALCULATE__H__

#include "investment.h"

void calculateGrowth(Investment *invp);

#endif //CALCULATE__H__